exports.info = (msg) => {
  console.log(`Info: ${msg}`);
}

exports.log = (msg) => {
  console.log(`Log: ${msg}`);
}

/* 
Ошибка!

exports = (msg) => {
  console.log(`Info: ${msg}`);
}

*/