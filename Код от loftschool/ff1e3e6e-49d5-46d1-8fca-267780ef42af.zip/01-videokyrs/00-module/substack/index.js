module.exports = (msg) => {
  console.log(`Info: ${msg}`);
}

module.exports.log = (msg) => {
  console.log(`Log: ${msg}`);
}