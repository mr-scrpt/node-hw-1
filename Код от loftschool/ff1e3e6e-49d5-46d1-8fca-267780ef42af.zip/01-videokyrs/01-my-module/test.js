module.exports = () => {
  console.log('Test module');
}