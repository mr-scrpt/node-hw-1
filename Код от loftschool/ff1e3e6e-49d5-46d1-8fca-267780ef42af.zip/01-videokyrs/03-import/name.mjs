const info = msg => {
  console.log(`Info: ${msg}`);
};

const log = msg => {
  console.log(`Log: ${msg}`);
};

export { info, log };
